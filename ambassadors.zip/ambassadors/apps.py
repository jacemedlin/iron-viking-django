from django.apps import AppConfig


class AmbassadorsConfig(AppConfig):
    name = 'ambassadors'
